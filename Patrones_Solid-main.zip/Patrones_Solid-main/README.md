# patrones-solid
Repositorio del curso de Patrones de diseño y principios SOLID
